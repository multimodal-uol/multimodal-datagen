from abc import ABCMeta


class Comparable(metaclass=ABCMeta):
    pass
