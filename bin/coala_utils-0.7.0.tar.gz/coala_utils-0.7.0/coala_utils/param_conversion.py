def negate(a):
    """
    Negates the given thing!

    >>> negate(True)
    False
    >>> negate('')
    True

    :param a: Anything that can be evaluated as a bool!
    """
    return not a
