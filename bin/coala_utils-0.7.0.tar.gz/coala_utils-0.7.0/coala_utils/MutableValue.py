class MutableValue:

    def __init__(self, val=None):
        self.value = val
